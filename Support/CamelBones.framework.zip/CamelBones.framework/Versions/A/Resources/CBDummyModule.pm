# The world's simplest Perl module:

1;
